package yusuf.platform.navdrawer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Rumah : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rumah)
    }
}